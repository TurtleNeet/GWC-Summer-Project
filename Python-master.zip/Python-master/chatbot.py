# --- Define your functions below! ---


# --- Put your main program below! ---
def main():
  while True:
    answer = input("(What will you say?) ")
    print("That's cool!")
