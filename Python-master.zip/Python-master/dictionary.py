def survey_start():

    print(input("Are you ready to do a survey? (Yes or No)" + "\n" + ""))

    answer = "Yes" or "No"

    if answer == "Yes":
        print("\n" + "Great, now let's find out which rapper you are." + "\n")

    elif answer == "No":
        print("You have no soul.")
        exit()

survey_start()
#
# Drake_Answers = {
# "Drake": 1,
# Saweetie_Answers =
#"Saweetie": 2,
# Rocky_Answers
#"A$AP Rocky": 3,
# "Kanye West": 4,
# "Playboi Carti": 5,
# "Nicki Minaj": 6
# }

def rap_Questions():

            q1 = [{"Question 1: ": "What's your name? ", "Answer: ": ""}]
            print(q1 + input("") + "\n")

            q2 = [{"Question 2: ": "What is your job", "Your options are: ": "student, technical, office, or freelance."}]
            print(q2 + input("Choice: ") + "\n")
            #Playboi & Saweetie = student
            #Kanye & Nicki = technical
            #Drake = office
            #A$AP = freelance

            q3 = [{"Question 3: ": "What's your drink of choice?", "Your options are: ": "champaigne, orange juice, whiskey, or bloody mary."}]
            print(q3 + input("Choice: ") + "\n")
            #Kanye = whiskey
            #Playboi Carti & Nicki = orange juice
            #Saweetie = bloody marie

            q4 = [{"Question 4: ": "What's your hobby of choice?", "Your options are: ": "singing, reading, writing, or playing games."}]
            print(q4 + input("Choice: ") + "\n")
            #Drake & Playboi = playing games
            #A$AP = reading
            #Saweetie & Nicki = singing
            #Kanye = writing

            q5 = [{"Question 5: ": "What are your favorite sneakers?", "Your options are: ": "Nike, Vans, Adidas, or heels."}]
            print(q5 + input("Choice: ") + "\n")
            #Drake & Playboi = Nike
            #A$AP = Vans
            #Kanye = Adidas
            #Nicki & Saweetie = heels

            q6 = [{"Question 6: ": "What do you like to wear?", "Your options are: ": "casual, preppy, hypebeast, or party."}]
            print(q6 + input("Choice: ") + "\n")
            #Kanye, A$AP = casual
            #Drake = preppy
            #Playboi = hypebeast
            #Nicki & Saweetie = party

            q7 = [{"Question 7: ": "And, lastly: What car would you buy?", "Your options are: ": "Lambo, G-Wagon, Ferrari, or Benz."}]
            print(q7 + input("Choice: ") + "\n")
            #Carti & Rocky = Lambo
            #Nicki & Saweetie = G-Wagon
            #Drake = Ferrari
            #Kanye = Benz

def rap_Results():

    if result == 1:
        1 = ("You are Drake, an ambitious determined, and energetic rapper.")
        print(1)

    elif result == 2:
        2 = ("You are Saweetie, an empowered, inspirational, and feminist rapper.")
        print(2)

    elif result == 3:
        3 = ("You are A$AP Rocky, a charming, kind, and thoughtful rapper.")
        print(3)

    elif result == 4:
        4 = ("You are Kanye West, a rapper who is moody, brutally honest, and outspoken.")
        print(4)

    elif result == 5:
        5 = ("You are Playboi Carti, a rapper who acts like a clown, is creative, and stylish.")
        print(5)
    elif
        6 = ("You are Nicki Minaj, a woman who is obsessive, a fighter, and protective of her loved ones.")
        print(6)
