import json

tweetFile = open("data.json", "r")
tweetData = json.load(tweetFile)
tweetFile.close()

print("tweet text:", tweetData[0]["text"])
