#imports the ability to get a random number (we will learn more about this later!)
from random import *
number = randint(0, 100)
print(number)
guess = input("Guess a number between 0 and 100: ")
guessTaken = 0

if not guess.isnumeric(): # checks if a string is only digits 0 to 9
	print("That's not a positive number, try again!")
else:
	guess = int(guess) # converts a string to an integer

while guessTaken < 3:
    guessTaken += 1

    if guess > number:
        guess = input("Guess a lower number. ")
        guess = int(guess)

    elif guess < number:
        guess = input("Guess a higher number. ")
        guess = int(guess)

    elif guess == number:
        print("You win!")
        break

    else:
        print("You lose!")
        break
        print(number)
#borrowed code from GWC GitHub
