# list name game
names = ["Hermione Granger", "Ron Weasley", "Harry Potter"]
description = ["brilliant", "funny", "instinctive"]
lucky_number = [4, 7, 8]

start = '''
Today you will find out who you are from the Golden Trio in Harry Potter.
All you have to do is answer two simple questions. Best of luck.
'''

print(start)
answer = input("")

print("Question 1: How would your friends describe you" + "\n")
print("Your options are: brilliant, funny, or instinctive.")
input("Answer: ")

if answer == 'brilliant', 'funny', | 'instinctive':
    print("Question 2: What is your lucky number?")
    print("Your options are: 4, 7, or 8.")

if answer == 'brilliant' & '4':
    print("You are the amazing witch Hermione Granger!")

if answer == 'funny' & '7':
    print("You are hilarious wizard Ron Weasley!")

if answer == 'instinctive' & '8'
    print("You are the 'Boy Who Lived' Harry Potter.")
