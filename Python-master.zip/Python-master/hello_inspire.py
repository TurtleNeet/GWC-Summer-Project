print("Hello World")

answer = input("Who inspires you? ")
print(answer, "inspires you!")
