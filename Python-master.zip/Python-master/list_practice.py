titans = ["Robin", "Beast Boy", "Raven", "Cyborg", "Starfire"]
favorite_numbers = [4, 8, 16, 24, 25]

for str in titans:
    print(str)
    print("\n")

for i in range(len(titans)):
    print(titans[i] + "\n")

for num in favorite_numbers:
    print(num)
    print("\n")

for i in range(len(favorite_numbers)):
    print(favorite_numbers[i] + "\n")
    print("* "+end="")
#Borrowed from GWC Presentation U1L6
