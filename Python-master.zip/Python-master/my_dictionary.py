import json

my_dict = {
"favorite animal":"Narwhal",
"favorite rappaer":"Drake"}

with open("data.json", "w") as json_file:
    json.dump(my_dict, json_file)
