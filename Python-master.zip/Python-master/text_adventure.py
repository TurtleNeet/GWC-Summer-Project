# control slash: comments out code you highlight & can undo it
answer = input("")
good_end = input("Congratulations! You have won ultimate power. Now what will you do with it? \n")
bad_end = print("Sadly, you ran out of time and the labybrinth disappeared. It will be another century until the labyrinth appears again.")

start = '''
You are an adventurer on a quest to win ultimate power. In order to gain ultimate power, you must survive a labybrinth.
You have only one hour to complete the labybrinth. As you walk around the maze, suddenly there is a burst of light.
A path appears on your right.
'''

print(start)
print("Will you go that way? You can only answer with 'Yes' or 'No'.")
input("Answer: ")

while answer == 'Yes' or 'No':
    if answer == 'Yes':
        input("You chose to go right. Now a minotaur is in front of you." + "\n")
        break
    elif answer == 'No':
        input("Too bad. Right is the only path open. Now a wizard is in front of you." + "\n")
        break
    else:
        print("You can only answer 'Yes' or 'No'")

while print("You chose to go right. Now a minotaur is in front of you." + "\n"):
    print("You can either kill the minotaur or befriend it.")
    print("You can only answer this with 'Kill' or 'Befriend'.")
    input("Answer: ")

    if answer == 'Kill':
        print("You have a long but, successful battle and slay the minotaur.")
        print("Because of the battle only ten minutes left before time is up and you are also injured.")
        print("What will you do?")
        print("Your options are 'Look for healing potion' and 'Attempt to find the end of the maze'.")
        input("Answer: ")

    if answer == 'Look for healing potion':
        print("You found the healing potion but, time is up.")
        print(bad_end)

    elif answer == 'Attempt to find the end of the maze':
        print("Without a healing potion you die.")
        print(bad_end)

if answer == 'Befriend':
        print("You learn the minotaur's name is Tiny and Tiny will help you.")
        print("Because of your friendship with Tiny, you are shown the way out of the maze.")
        print("You have now reached the end the maze.")
        input(good_end)

# while print("Too bad. Right is the only path open. Now a wizard is in front of you." + "\n"):
#     print("The wizard gives you a riddle.")
# #     print("What do you call it when a parachute doesn't open?")
#     print("Your options are Jumping to a conclusion ('A') or Instant death ('B')")
# # #      print("You can only write 'A' or 'B' to answer.")
# #      input("Answer: ")
# #
#     if answer == 'A':
#   #       print("You are right! Jumping to a conclusion.")
#     #     print("The wizard is impressed by your cleverness and decides to give you a path to the exit.")
#       #   print("As you follow the path to the exit you realize only thirty minutes are left.")
#         print("A portal now appears in front of you. Will you go in?")
#         break
#
#     elif answer == 'B':
#         print("Too bad. It's not instant death.")
#         print("The wizard is disappointed in you and decides to turn you into a toad.")
#         print("As a toad, you attempt to find the end of the maze.")
#         print(bad_end)
#          break
# while print("A portal now appears in front of you. Will you go in?"):
#     print("You can choose to 'Go in' or 'Find the end of the maze'")
#     input("Answer: ")#     if answer == 'Go in':
#         print("The portal leads you to the end of the maze.")
#         input(good_end)
#         break
#     elif answer == 'Find the end of the maze'
#         print(bad_end)
#         break
