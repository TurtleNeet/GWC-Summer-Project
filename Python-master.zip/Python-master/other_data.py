

import json

myFile = open("data.json", "r")
diction = json.load(myFile)
myFile.close()

print(diction[favorite animal])
