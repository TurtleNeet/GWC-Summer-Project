ages = [5, 12, 3, 56, 24, 78, 1, 15, 44]
total = 0
for num in ages:
    total += num

average = total/len(ages)
round(average)

print("The average is: " + str(round(average)))
