# Safe_and_Sound
Final GWC Project
Use the most recent news file bc it has everything I changed and the summaries just the way I want them.
