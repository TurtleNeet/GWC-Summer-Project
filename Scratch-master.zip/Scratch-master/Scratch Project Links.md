# Scratch-Projects
All About Me: 
https://scratch.mit.edu/projects/320211379

Dance Battle: 
https://scratch.mit.edu/projects/320336309

Fortune Teller: 
https://scratch.mit.edu/projects/320480208
